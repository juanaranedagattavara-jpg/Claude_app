<?php get_header(); ?>

<main id="primary" class="site-main">
    <?php
    // Cargar todas las secciones del landing
    get_template_part('template-parts/section', 'nosotros');
    get_template_part('template-parts/section', 'timeline');
    get_template_part('template-parts/section', 'servicios');
    get_template_part('template-parts/section', 'testimonios');
    get_template_part('template-parts/section', 'equipo');
    get_template_part('template-parts/section', 'blog-preview');
    get_template_part('template-parts/section', 'contacto');
    ?>
</main>

<?php get_footer(); ?>
